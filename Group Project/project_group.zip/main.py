import overheads, cashonhand, profitloss

# creating a main function
def mainfunction():
    overheads.overheadscalc
    cashonhand.cashonhandcalc
    profitloss.profitlosscalc
mainfunction()